<?php
include_once("./config/config.php");
include_once(LIB_DIR."Core.php");
new Core();
