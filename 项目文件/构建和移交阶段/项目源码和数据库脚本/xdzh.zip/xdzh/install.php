<?php
define("INSTALL",true);
include_once("./config/config.php");
include_once(LIB_DIR."Install.php");
new Install();
