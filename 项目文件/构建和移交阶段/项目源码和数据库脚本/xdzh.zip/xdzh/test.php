<?php

echo time();
?>