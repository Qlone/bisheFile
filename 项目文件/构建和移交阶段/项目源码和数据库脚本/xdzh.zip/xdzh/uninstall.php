<?php
define("INSTALL",true);
include_once("./config/config.php");
var_dump(install_lock_clear());
