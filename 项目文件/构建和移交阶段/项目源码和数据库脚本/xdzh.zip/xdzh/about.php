<?php
include_once("./config/config.php");
include_once(LIB_DIR."About.php");
new About();
